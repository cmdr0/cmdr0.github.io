: created 6-14-16
: by Spin Master Toys

This sketch is to move two daisy chained Meccano servos by input of an ultrasonic ping sensor.included there is a step by step instructions on how to build, wire, and program.Also if you have a small robot I recommend using his neck pieces for the claw instead of the current 4 piece claw build.
							-Cheers and happy hacking.
								 Meccano team 